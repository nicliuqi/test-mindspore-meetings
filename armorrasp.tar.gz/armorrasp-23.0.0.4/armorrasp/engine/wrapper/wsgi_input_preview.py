"""Do wsgi_input_preview"""
import sys
from io import BytesIO

from armorrasp.core.runtime_info_storage import runtime


def preview_callback(preview, end_of_input):
    """Do preview_callback"""
    runtime.memory_request_input_preview(preview, end_of_input)


class WSGIInputWrapper:
    """Do WSGIInputWrapper"""

    DEFAULT_MAX_PREVIEW_LENGTH = 4096

    def __init__(self, original, hint_length=None,
                 max_preview_length=None):
        self.original = original
        self.primordial_read = 0
        self.primordial_hint_length = hint_length \
            if hint_length is not None else sys.maxsize
        self.preview_max_length = max_preview_length \
            if max_preview_length is not None \
            else self.DEFAULT_MAX_PREVIEW_LENGTH
        self.residue_preview = self.preview_max_length
        self.buffer = BytesIO()

    def _flow_into_preview(self, data, hint_size=0):
        if not self.residue_preview:
            return
        try:
            self.primordial_read += len(data)
            primordial_preview = data[:self.residue_preview]
            self.buffer.write(primordial_preview)
            self.residue_preview -= len(primordial_preview)
            end_of_input = not data or hint_size is None \
                or hint_size < 0 or len(data) < hint_size \
                or self.primordial_read >= self.primordial_hint_length
            if not self.residue_preview or end_of_input:
                try:
                    preview_callback(self.buffer.getvalue(), end_of_input)
                finally:
                    self.residue_preview = 0
                    self.buffer = None
        # 此处的业务逻辑为在不影响业务数据的传输的情况下，对原始业务数据进行包装缓存，使其body内容在4K以内
        # 若包装过程发生异常则中断该数据的包装缓存，不会对业务产生影响
        except Exception as ex:
            pass

    def read(self, *args, **kwargs):
        data = self.original.read(*args, **kwargs)
        size = args[0] if args else kwargs.get("size")
        self._flow_into_preview(data, hint_size=size)
        return data

    def readline(self, *args, **kwargs):
        data = self.original.readline(*args, **kwargs)
        self._flow_into_preview(data)
        return data

    def readlines(self, *args, **kwargs):
        it = self.original.readlines(*args, **kwargs)
        for data in it:
            self._flow_into_preview(data)
            yield data
        else:
            self._flow_into_preview(b"")

    def __iter__(self):
        for data in self.original:
            self._flow_into_preview(data)
            yield data
        else:
            self._flow_into_preview(b"")
