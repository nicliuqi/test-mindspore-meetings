"""Do django_middleware"""
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.engine.wrapper.wsgi_input_preview import WSGIInputWrapper
from armorrasp.config import logger_config

logger = logger_config("django_middleware")


def do_patch(queue):
    """Do Django do_patch"""
    try:
        import django
        from django import VERSION as DJANGO_VERSION
        from django.core.handlers.base import BaseHandler
        from django.core.handlers import wsgi
        from armorrasp.engine.wrapper.django_middleware_wrap import \
            DjangoMiddlewareWrap
        logger.debug("Detected Django version %r", DJANGO_VERSION)
    except ImportError:
        logger.warning("No module named django")
        return

    try:
        @patch(django.core.handlers.base.BaseHandler, "load_middleware")
        def _django_init(orig, django_self, *args, **kwargs):
            """Do _django_init"""

            res = orig(django_self, *args, **kwargs)
            if DJANGO_VERSION[:2] >= (2, 0):
                insert_middleware_v2(django_self,
                                     DjangoMiddlewareWrap(),
                                     *args, **kwargs)
            else:
                insert_middleware_v1(django_self,
                                     DjangoMiddlewareWrap(),
                                     *args, **kwargs)
            return res
        logger.info('hook django.core.handlers.wsgi.'
                    'WSGIHandler.load_middleware sucess')
    except Exception as err:
        logger.error('hook django.core.handlers.wsgi.'
                     'WSGIHandler.load_middleware failed %s' % err)

    try:
        @patch(django.core.handlers.wsgi.WSGIHandler, "__call__")
        def _django_wsgi_hook(orig, django_self, *args, **kwargs):
            """Do _django_wsgi_hook"""
            environ = args[0]
            wsgi_input = environ.get("wsgi.input")
            current_request = runtime.get_latest_request()
            if wsgi_input is not None and current_request is not None \
                    and not isinstance(wsgi_input, WSGIInputWrapper):
                input_wrapper = \
                    WSGIInputWrapper(wsgi_input,
                                     current_request.content_length, 4096)
                environ["wsgi.input"] = input_wrapper

            return orig(django_self, *args, **kwargs)

        logger.info('hook django.core.handlers.wsgi.WSGIHandler'
                    '__call__ sucess')
    except Exception as err:
        logger.error('hook django.core.handlers.wsgi.WSGIHandler'
                     '__call__ failed %s' % err)


def insert_middleware_v1(django_self, middleware, *args, **kwargs):
    """Do insert_middleware_v1"""
    logger.info("Insert old-style Django middleware")
    # Insert rasp middleware
    try:
        django_self._view_middleware.insert(0, middleware.observe_process)
        django_self._response_middleware.append(middleware.respond_process)
        django_self._exception_middleware.append(middleware.abnormal_process)
    except Exception as err:
        logger.warning("Error while inserting our middleware %s" % err)


def insert_middleware_v2(django_self, middleware, *args, **kwargs):
    """Do insert_middleware_v2"""
    logger.info("Insert new-style Django middleware")

    def _extract(is_async=False):
        """Do _extract"""
        return is_async

    orig_mw_chain = django_self._middleware_chain

    is_async = _extract(*args, **kwargs)
    if is_async:
        observe_process = django_self.\
            adapt_method_mode(is_async, middleware.observe_process)

        async def mw_chain(request):
            """Do if_mw_chain"""
            response = await orig_mw_chain(request)
            res = middleware.respond_process(request, response)
            return res
    else:
        observe_process = middleware.observe_process

        def mw_chain(request):
            """Do else_mw_chain"""
            response = orig_mw_chain(request)
            res = middleware.respond_process(request, response)
            return res

    try:
        django_self._view_middleware.insert(0, observe_process)
        django_self._exception_middleware.append(middleware.abnormal_process)
        django_self._middleware_chain = mw_chain
    except Exception as err:
        logger.warning("Error while inserting our middleware %s" % err)
