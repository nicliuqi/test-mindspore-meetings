"""Do engine init work"""
