"""Do app_context"""
import os
import re
import platform
import sys

import pkg_resources

from .__about__ import __version__
from .utils.pyrasp_exception import UnsupportedFrameworkVersionByRASP
from .utils.pyrasp_exception import UnsupportedPythonVersionByRASP
from .utils.util import now


def get_installed_distributions():
    """Do get_installed_distributions"""
    return pkg_resources.working_set


def get_package_version(package_name):
    """Do get_package_version"""
    for package in get_installed_distributions():
        if package.project_name == package_name:
            return package.version


def parse_version(version):
    """Do parse_version"""
    return tuple(map(int, version.split(".")[:2]))


def dict_to_str(json_data):
    """Do dict_to_str"""
    new_list = {}
    if json_data:
        for item in json_data.keys():
            new_list[str(item)] = str(json_data[item])
    return new_list


XARMOR_BASE_HOME = os.getcwd()
SYS_PATH = sorted(sys.path, key=len, reverse=True)

XARMOR_SUPPORTED_PYTHON_VERSIONS = {(3, 5), (3, 6), (3, 7), (3, 8), (3, 9), (3, 10)}


class AppContext(object):
    """Do AppContext"""
    def get_agent_contexts(self):
        res = {}
        res.update({"host_name": platform.node()})
        res.update({"server.hostname": platform.node()})
        res.update(self._env_ip())
        res.update({"raspPath": XARMOR_BASE_HOME})
        res.update({"xArmorPath": XARMOR_BASE_HOME})
        res.update({"xArmor.xArmor-spy.version": __version__})
        res.update({"xArmor.xArmor-boot.version": __version__})
        res.update({"xArmor.xArmor-core.version": __version__})
        res.update(self._runtime_python_info())
        res.update(self._app_framework())
        res.update(self._update_env())
        res.update(self._app_dependencies())
        res.update(self._os_info())
        res.update(self._rasp_agent())
        return res

    @staticmethod
    def _env_ip():
        pattern = r"win"
        if re.match(pattern, sys.platform) is not None:
            return {"hostIP": "127.0.0.1",
                    "server.ip": "127.0.0.1"}
        else:
            try:
                # 在Linux环境下采用绝对路径的ifconfig命令获取本机的host IP
                # 该场景采用socket方法获取IP可能会失效，因此采用ifconfig+正则表达式的方法
                # 若没有root权限使用ifconfig，则会触发异常捕获使用默认的host IP
                host_ip = \
                    os.popen(""" ifconfig -a | grep inet | grep -v 127.0.0.1 \\
                                    | grep -v inet6 | \\
                                    awk '{print $2}'| \\
                                    tr -d \"addr:\" """).readlines()
            except Exception as e:
                host_ip = ["127.0.0.1"]
            ip_list = ''
            for h_i in host_ip:
                if ip_list is '':
                    ip_list = ip_list + h_i.replace("/n", "")
                else:
                    ip_list = ip_list + ',' + h_i.replace("/n", "")
            return {"hostIP": ip_list,
                    "server.ip": ip_list}

    @staticmethod
    def _rasp_agent():
        return {
            "agent_type": "xarmor python rasp",
            "agent_version": __version__,
        }

    @staticmethod
    def _app_framework():
        flask = get_package_version("Flask")
        django = get_package_version("Django")

        if django:
            django_version = parse_version(django)
            # Check for Django version
            if django_version < (1, 6):
                raise UnsupportedFrameworkVersionByRASP("django", django)

            return {"server_type": "Django", "server_version": django}
        elif flask:
            flask_version = parse_version(flask)
            # Check for Flask version
            if flask_version < (0, 10):
                raise UnsupportedFrameworkVersionByRASP("flask", flask)

            return {"server_type": "Flask", "server_version": flask}
        else:
            return {"server_type": None, "server_version": None}

    @staticmethod
    def _os_info():
        return {
            "os_type": "{}-{}".format(platform.machine(), sys.platform),
            "hostname": platform.node(),
            "server.hostname": platform.node(),
        }

    @staticmethod
    def _runtime_python_info():
        python_version = tuple(map(int, platform.python_version_tuple()[:2]))
        if python_version not in XARMOR_SUPPORTED_PYTHON_VERSIONS:
            raise UnsupportedPythonVersionByRASP(platform.python_version())

        python_build = platform.python_build()
        version = "{} ({}, {})".format(
            platform.python_version(), python_build[0], python_build[1]
        )

        return {
            "platform": platform.python_implementation(),
            "platform.version": version,
        }

    @staticmethod
    def _update_env():
        env_dict = os.environ
        if env_dict is not None:
            return {"environ": dict_to_str(env_dict)}

    @staticmethod
    def _app_dependencies():
        dependencies = [
            {"project_name": dis.project_name, "version": dis.version}
            for dis in get_installed_distributions()
        ]
        return {"dependencies": dependencies}

    @staticmethod
    def _update_time():
        return {"lastUpdateTime": now().isoformat()}
