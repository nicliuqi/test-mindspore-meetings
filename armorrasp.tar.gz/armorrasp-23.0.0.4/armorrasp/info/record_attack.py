"""Do record_attack"""
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.info.common import common_info
from armorrasp.config import logger_config
from armorrasp.utils.stack_utils import get_filtered_stack_string_list
from armorrasp.utils.util import get_string_md5
from armorrasp.utils.wrappor import exception_catch

logger = logger_config("record_attack")


@exception_catch("Failed to record attack")
def record_attack(queue, attack_type, intercept_state,
                  plugin_message, params=None, request=None):
    """Record an attack."""
    if not request:
        request = runtime.get_latest_request()

    attack_params = {}
    attack_params.update({"params": params})
    stack = get_filtered_stack_string_list()
    attack_params.update({"stack": stack})
    attack_params.update({"stack_md5": get_string_md5("".join(stack))})

    payload = {}
    payload.update(request.attack_request_info)
    payload.update(common_info.get_common_info)
    tmp = {
        "attack_type": attack_type,
        "intercept_state": intercept_state,
        "plugin_message": plugin_message,
        "attack_params": attack_params,
    }
    payload.update(tmp)

    queue.put(payload)
