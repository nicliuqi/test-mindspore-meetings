"""Do common"""
from datetime import datetime


class CommonInfo(object):
    """Do CommonInfo"""
    def __init__(self):
        self.server_version = ''
        self.plugin_confidence = 100
        self.plugin_name = 'xArmor-python-rasp plugin'
        self.plugin_algorithm = 'xArmor-python-rasp'
        self.rasp_id = "0",
        self.server_type = ''
        self.server_nic = []
        self.server_ip = ''

    def update_info(self, get_all_contexts):
        self.server_version = get_all_contexts.get('server_version', '')
        self.server_type = get_all_contexts.get('server_type', '')

    def update_agent_id(self, u_a_id):
        self.rasp_id = u_a_id

    @property
    def get_common_info(self):
        dt = datetime.now()
        str_time = dt.strftime('%Y-%m-%d''T''%H:%M:%S''+0800')
        return {
            "server_version": self.server_version,
            "plugin_confidence": self.plugin_confidence,
            "plugin_name": self.plugin_name,
            "plugin_algorithm": self.plugin_algorithm,
            "event_type": "attack",
            "event_time": str_time,
            "rasp_id": self.rasp_id,
            "server_type": self.server_type,
            "server_nic": self.server_nic,
            "server_ip": self.server_ip,
        }


common_info = CommonInfo()
