"""Do sqli init work"""
