"""Do hook_mysql"""
from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.sqli import sqli_detect
from armorrasp.config import logger_config

logger = logger_config("hook_mysql")


def do_patch(queue):
    """Do hook_mysql do_patch"""
    try:
        import pymysql
    except ImportError:
        logger.warning("No module named pymysql")
        return
    try:
        @patch(pymysql.cursors.Cursor, 'execute', block=False,
               report_name="plugin.python.pymysql")
        def _rasp_execute(orig_execute, *args, **kwargs):
            """Do Cursor_execute _rasp_execute"""
            if CONFIG["SQLI_ENABLE"]:
                sqli_detect.SQLI.detect(queue, *args, **kwargs)
            return orig_execute(*args, **kwargs)
    except Exception as err:
        logger.error("hook pymysql failed, %s" % err)

    try:
        @patch(pymysql.cursors.Cursor, 'executemany', block=False,
               report_name="plugin.python.pymysql")
        def _rasp_execute(orig_execute, *args, **kwargs):
            """Do Cursor_executemany _rasp_execute"""
            if CONFIG["SQLI_ENABLE"]:
                sqli_detect.SQLI.detect(queue, *args, **kwargs)
            return orig_execute(*args, **kwargs)
    except Exception as err:
        logger.error("hook pymysql failed, %s" % err)
