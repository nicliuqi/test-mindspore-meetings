"""Do hook_os_system"""
import os

from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.cmdi import cmdi_injection
from armorrasp.plugins.cmdi.cmdi_handler import cmdi_handler
from armorrasp.config import logger_config

logger = logger_config("hook_os_system")


def do_patch(queue):
    """Do hook_os_system do_patch"""
    try:
        @patch(os, 'system', block=False,
               report_name="plugin.python.shell.os_system")
        def _our_os_system(orig_os_system, *args, **kwargs):
            """Do os_system _our_os_system"""

            if CONFIG["CMDI_ENABLE"]:
                check_params = \
                    cmdi_handler("ARG_0,KWARG:command", *args, **kwargs)
                for check_param in check_params:
                    cmdi_injection.\
                        CmdInjection.detect_os_system(queue, check_param)

            return orig_os_system(*args, **kwargs)
    except Exception as err:
        logger.error("hook os.system failed, %s" % err)

    try:
        @patch(os, 'popen', block=False,
               report_name="plugin.python.shell.os_popen")
        def _our_os_system(orig_os_system, *args, **kwargs):
            """Do os_popen _our_os_system"""

            if CONFIG["CMDI_ENABLE"]:
                check_params = \
                    cmdi_handler("ARG_0,KWARG:cmd", *args, **kwargs)
                for check_param in check_params:
                    cmdi_injection.\
                        CmdInjection.detect_os_system(queue, check_param)

            return orig_os_system(*args, **kwargs)
    except Exception as err:
        logger.error("hook os.system failed, %s" % err)
