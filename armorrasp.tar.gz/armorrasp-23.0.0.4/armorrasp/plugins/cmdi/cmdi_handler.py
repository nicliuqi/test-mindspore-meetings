"""Do cmdi_handler"""
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.plugins.common import parse_type
from armorrasp.utils.util import INTEGER_CLASS, ensure_input_string
from armorrasp.utils.wrappor import exception_catch


@exception_catch("Failed to handler cmdi sources", return_value=[])
def cmdi_handler(source_type, *args, **kwargs):
    """Do cmdi_handler"""
    request = runtime.get_latest_request()
    sources = []
    if not request:
        return sources

    for tmp in parse_type(source_type):
        if isinstance(tmp, INTEGER_CLASS) and len(args) > tmp:
            sources.append(_convert_cmdi_tostring(args[tmp]))
        elif kwargs and tmp in kwargs:
            sources.append(_convert_cmdi_tostring(kwargs[tmp]))
    return sources


def _convert_cmdi_tostring(input_data):
    """Do _convert_cmdi_tostring"""
    if isinstance(input_data, list):
        input_data = " ".join(input_data)

    return ensure_input_string(input_data)
