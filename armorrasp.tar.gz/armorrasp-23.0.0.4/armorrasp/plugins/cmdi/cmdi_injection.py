"""Do cmdi_injection"""
from armorrasp.config import CONFIG
from armorrasp.info.record_attack import record_attack
from armorrasp.utils import pyrasp_exception
from armorrasp.config import logger_config
from armorrasp.utils.wrappor import exception_catch

logger = logger_config("cmd_injection")


class CmdInjection:
    """Do CmdInjection"""

    @classmethod
    @exception_catch("Failed to check cmdi", return_value="")
    def detect_os_system(cls, queue, check_param):
        is_attack = True

        if not is_attack:
            return None
        if CONFIG["CMDI_BLOCK"]:
            record_attack(queue, "command", "block", "CMDInjection",
                          check_param)
            raise pyrasp_exception.RaspSecurityException('CMDInjection')
        record_attack(queue, "command", "log", "CMDInjection", check_param)
        return

    @classmethod
    @exception_catch("Failed to check cmdi", return_value="")
    def detect_subprocess_popen(cls, queue, check_param):
        is_attack = True

        if not is_attack:
            return None
        if CONFIG["CMDI_BLOCK"]:
            record_attack(queue, "command", "block", "CMDInjection",
                          check_param)
            raise pyrasp_exception.RaspSecurityException('CMDInjection')
        record_attack(queue, "command", "log", "CMDInjection", check_param)
        return
