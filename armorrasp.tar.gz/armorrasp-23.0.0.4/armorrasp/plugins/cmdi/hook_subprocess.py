"""Do hook_subprocess"""
import subprocess

from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.cmdi import cmdi_injection
from armorrasp.plugins.cmdi.cmdi_handler import cmdi_handler
from armorrasp.config import logger_config

logger = logger_config("hook_subprocess")


def do_patch(queue):
    """Do hook_subprocess do_patch"""

    try:
        @patch(subprocess, 'check_output', block=False,
               report_name="plugin.python.shell.check_output")
        def our_subprocess_popen(orig_subprocess_popen, *args, **kwargs):
            """Do subprocess_check_output our_subprocess_popen"""
            if CONFIG["CMDI_ENABLE"]:

                check_params = \
                    cmdi_handler("ARG_0,KWARG:args", *args, **kwargs)
                for check_param in check_params:
                    cmdi_injection.CmdInjection.\
                        detect_subprocess_popen(queue, check_param)

            return orig_subprocess_popen(*args, **kwargs)

        logger.info("hook subprocess.check_output success")
    except Exception as err:
        logger.error("hook subprocess.check_output failed, %s" % err)

    try:
        @patch(subprocess, 'check_call', block=False,
               report_name="plugin.python.shell.check_call")
        def our_subprocess_check_call(orig_subprocess_popen, *args, **kwargs):
            """Do subprocess_check_call our_subprocess_popen"""
            if CONFIG["CMDI_ENABLE"]:

                check_params = \
                    cmdi_handler("ARG_0,KWARG:args", *args, **kwargs)
                for check_param in check_params:
                    cmdi_injection.CmdInjection.\
                        detect_subprocess_popen(queue, check_param)

            return orig_subprocess_popen(*args, **kwargs)

        logger.info("hook subprocess.check_call success")
    except Exception as err:
        logger.error("hook subprocess.check_call failed, %s" % err)

    try:
        @patch(subprocess, 'call', block=False,
               report_name="plugin.python.shell.call")
        def our_subprocess_call(orig_subprocess_popen, *args, **kwargs):
            """Do subprocess_call our_subprocess_popen"""
            if CONFIG["CMDI_ENABLE"]:

                check_params = \
                    cmdi_handler("ARG_0,KWARG:args", *args, **kwargs)
                for check_param in check_params:
                    cmdi_injection.CmdInjection.\
                        detect_subprocess_popen(queue, check_param)

            return orig_subprocess_popen(*args, **kwargs)

        logger.info("hook subprocess.call success")
    except Exception as err:
        logger.error("hook subprocess.call failed, %s" % err)
