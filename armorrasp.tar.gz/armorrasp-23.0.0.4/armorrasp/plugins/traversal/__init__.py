"""Do traversal init work"""
