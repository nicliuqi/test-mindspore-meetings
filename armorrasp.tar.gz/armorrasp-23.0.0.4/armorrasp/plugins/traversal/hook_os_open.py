"""Do hook_os_open"""
from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.traversal import dir_traversal
from armorrasp.config import logger_config

logger = logger_config("hook_builtin_open")

NAME = "file_io_os_open"


def do_patch(queue):
    """Do hook_os_open do_patch"""
    try:
        import os

        @patch(os, 'open', block=False,
               report_name="plugin.python.shell.os_popen")
        def _our_os_open(orig_os_open, *args, **kwargs):
            """Do os_open _our_os_open"""
            if CONFIG["DIR_TRAVERSAL_ENABLE"]:
                dir_traversal.DirTraversal.\
                    detect_dir_traversal(queue, *args, **kwargs)
            return orig_os_open(*args, **kwargs)

        logger.info("hook os.open success")
    except Exception as err:
        logger.error("hook os.open failed, %s" % err)
