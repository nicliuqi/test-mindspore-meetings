"""Do hook_builtin_open"""
import builtins

from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.traversal import dir_traversal
from armorrasp.config import logger_config

logger = logger_config("hook_builtin_open")


def do_patch(queue):
    """Do hook_builtin_open do_patch"""
    try:
        @patch(builtins, 'open', block=False,
               report_name="plugin.python.shell.os_popen")
        def _our_builtins_open(orig_builtins_open, *args, **kwargs):
            """Do builtins_open _our_builtins_open"""
            if CONFIG["DIR_TRAVERSAL_ENABLE"]:
                dir_traversal.DirTraversal.\
                    detect_dir_traversal(queue, *args, **kwargs)
            return orig_builtins_open(*args, **kwargs)
        logger.info("hook builtins.open success")
    except Exception as err:
        logger.error("hook builtins.open failed, %s" % err)
