"""Do dir_traversal"""
from armorrasp.config import CONFIG
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.info.record_attack import record_attack
from armorrasp.utils import pyrasp_exception
from armorrasp.config import logger_config
from armorrasp.utils.util import ensure_input_string
from armorrasp.utils.wrappor import exception_catch

logger = logger_config("dir_traversal")


class DirTraversal:
    """Do DirTraversal"""

    block = False

    @staticmethod
    @exception_catch("Failed to check dir_traversal", return_value="")
    def detect_dir_traversal(queue, *args, **kwargs):
        request = runtime.get_latest_request()
        if not request:
            return

        is_attack = False
        mess = ""
        sensitive_str = CONFIG["DIR_TRAVERSAL_BLACK"]

        param = ensure_input_string(args[0])

        for sen_str in sensitive_str:
            if sen_str in param:
                mess = \
                    'Directory - Detected dangerous method call {0} ' \
                    'in directory query'.format(sen_str)
                is_attack = True
                break

        # 如果开启了阻断且包含特殊命令连接符则阻断攻击，否则只报警
        if not is_attack:
            return None
        if CONFIG["DIR_TRAVERSAL_BLOCK"]:
            record_attack(queue, "directory", "block", mess,
                          params=args[0], request=request)
            raise pyrasp_exception.RaspSecurityException('directory')
        record_attack(queue, "directory", "log", mess,
                      params=args[0], request=request)
        return
