"""Do plugins init work"""
