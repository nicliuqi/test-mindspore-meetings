"""Do plugins_common"""
UNDERSCORE = "_"
COMMA = ","
COLON = ":"
ARG = "ARG"
KWARG = "KWARG"


def parse_type(p_type):
    """Do parse_type"""

    res = []

    if not p_type:
        return []

    for item in p_type.split(COMMA):

        # handle ARG_#
        if item.startswith(ARG + UNDERSCORE):
            arg_num = item.split(UNDERSCORE)[1]
            res.append(int(arg_num))

        # handle KWARG:name
        elif item.startswith(KWARG + COLON):
            kwarg_name = item.split(COLON)[1]
            res.append(kwarg_name)

        else:
            return []

    return res
