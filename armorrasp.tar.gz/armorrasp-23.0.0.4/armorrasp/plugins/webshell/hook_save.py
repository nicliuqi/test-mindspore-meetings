"""Do hook_save"""
from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.webshell import webshell_upload
from armorrasp.config import logger_config

logger = logger_config("hook_save")

NAME = "file_io_os_open"


def do_patch(queue):
    """Do hook_save"""
    try:
        import werkzeug.datastructures
    except ImportError:
        logger.warning("No module named werkzeug.datastructures")
        return
    try:
        @patch(werkzeug.datastructures.FileStorage, 'save', block=False,
               report_name="plugin.python.shell.os_popen")
        def _our_os_open(orig_os_open, *args, **kwargs):
            """Do FileStorage_save _our_os_open"""
            if CONFIG["WEBSHELL_UPLOAD_ENABLE"]:
                webshell_upload.WebshellUpload.\
                    detect_webshell(queue, *args, **kwargs)
            return orig_os_open(*args, **kwargs)
        logger.info("hook werkzeug.datastructures.FileStorage.save success")
    except Exception as err:
        logger.error("hook werkzeug.datastructures."
                     "FileStorage.save failed, %s" % err)
