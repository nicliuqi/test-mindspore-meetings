"""Do config"""
import os
import sys
import logging
from os import getenv
from os.path import isfile, expanduser

from armorrasp.constants_var import ENABLE, \
    BACKEND_URL, TENANT_ID, HEARTBEAT_INTERVAL

if sys.version_info[0] < 3:
    from ConfigParser import Error as ConfigError, RawConfigParser
else:
    from configparser import Error as ConfigError, RawConfigParser

FILE_ROOT_PATH = expanduser("~/.xarmor_pyrasp.ini")

CONFIG_DEFAULT_VALUE = {
    "ENABLE": ENABLE,
    "BACKEND_URL": BACKEND_URL,
    "TENANT_ID": TENANT_ID,
    "APP_ID": None,
    "APP_TOKEN": None,
    "MAX_QUEUE_LENGTH": 4096,
    "AGENT_ID": "0",
    "HEARTBEAT_INTERVAL": HEARTBEAT_INTERVAL,
    "LOGPATH": "./xArmor_python_agent_log.log",
    "DEBUG": False,
    "CMDI_ENABLE": True,
    "SQLI_ENABLE": True,
    "DESERIALIZATION_ENABLE": True,
    "WEBSHELL_UPLOAD_ENABLE": True,
    "DIR_TRAVERSAL_ENABLE": True,
    "CMDI_BLOCK": False,
    "SQLI_BLOCK": False,
    "DESERIALIZATION_BLOCK": False,
    "WEBSHELL_UPLOAD_BLOCK": False,
    "DIR_TRAVERSAL_BLOCK": False,
    "SQLI_BLACK": ['load_file', 'benchmark', 'sleep',
                   'pg_sleep', 'updatexml', 'extractvalue'],
    "CMDI_BLACK": ['!', ';', '&', '<', '>', '|', '~', '`', 'whoami'],
    "WEBSHELL_UPLOAD_BLACK": ['.py', '.sh', '.cgi', '.perl', '.pl'],
    "DIR_TRAVERSAL_BLACK": ['../', '/etc', '/proc', '/sys', '/var/log'],
    "DESERIALIZATION_BLACK": ['system', 'subprocess',
                              '__builtin__', 'builtins',
                              'globals', 'open', 'popen', '!!python']
}

loggers = {}

LOG_FORMAT = '[%(asctime)s] %(levelname)s [%(name)s] %(message)s'


def logger_config(logging_name):
    """Do logger_config"""
    global loggers

    if loggers.get(logging_name):
        return loggers.get(logging_name)

    log_path = CONFIG["LOGPATH"]

    logger = logging.getLogger(logging_name)
    logger.handlers.clear()

    if CONFIG["DEBUG"] is True:
        level = logging.DEBUG
    else:
        level = logging.INFO

    logger.setLevel(level)

    handler = logging.FileHandler(log_path, encoding='UTF-8')
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(LOG_FORMAT))
    logger.addHandler(handler)

    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(logging.Formatter(LOG_FORMAT))
    logger.addHandler(console)

    loggers[logging_name] = logger
    return logger


class SystemConfig(object):
    """Do SystemConfig"""

    FILE_NAME_SPC = "XARMOR_PYRASP_CONFIG"
    FILE_ROOT_PATH = FILE_ROOT_PATH

    def __init__(self, tolerant_values=None):
        self.config = {}

        if tolerant_values is None:
            tolerant_values = CONFIG_DEFAULT_VALUE

        self.tolerant_values = tolerant_values

        self.loaders = [
            self.load_from_volerant_values,
            self.load_from_document,
            self.load_from_surrounding,
        ]

        self.config_path = None

    def start_load(self):
        root_deploy = {}

        for loader in self.loaders:
            loaded = loader()

            if loaded:
                root_deploy.update(loaded)

        self.config = root_deploy

    def load_from_volerant_values(self):
        return self.tolerant_values

    def load_from_document(self):

        file_path = (
            self.config_path
            or self._document_path_from_sur()
            or self._document_path_from_root()
            or self._document_path_from_native()
        )

        if not file_path:
            return {}

        config = RawConfigParser()

        try:
            config.read(file_path)

            deploy_dict = {}
            for option in config.options("xarmor-pyrasp"):
                upper_option = option.upper()
                deploy_dict[upper_option] = self._force_value(
                    upper_option, config.get("xarmor-pyrasp", option))

            return deploy_dict
        except ConfigError:
            return {}

    def load_from_surrounding(self):
        env_config = {}
        for env_var, value in os.environ.items():
            if env_var.startswith("XARMOR_"):
                key = env_var[7:].upper()
                env_config[key] = self._force_value(key, value)
        return env_config

    def _force_value(self, name, value):
        tolerant_value = self.tolerant_values.get(name)
        if isinstance(tolerant_value, bool):
            value = value.lower().strip() in ("1", "true", "yes", "y")
        elif isinstance(tolerant_value, (int, float)):
            try:
                value = type(tolerant_value)(value)
            except ValueError:
                value = tolerant_value
        return value

    def _document_path_from_sur(self):
        path = getenv(self.FILE_NAME_SPC, default=None)

        if path and isfile(path):
            return path

    def _document_path_from_root(self):
        if self.FILE_ROOT_PATH and isfile(self.FILE_ROOT_PATH):
            return self.FILE_ROOT_PATH

    @staticmethod
    def _document_path_from_native():
        if isfile("xarmor_pyrasp.ini"):
            return os.path.join(os.getcwd(), "xarmor_pyrasp.ini")

    def __getitem__(self, name):
        return self.config[name]

    def __setitem__(self, name, value):
        transformed_val = self._force_value(name, value)
        self.config[name] = transformed_val


CONFIG = SystemConfig()
CONFIG.start_load()
