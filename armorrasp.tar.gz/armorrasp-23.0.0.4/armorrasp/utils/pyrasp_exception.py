#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Do pyrasp_exception"""


class RaspSecurityException(Exception):
    """DO RaspSecurityException"""
    def __init__(self, expression):
        self.expression = expression

    def __str__(self):
        return "Request blocked by xArmor-rasp"


class UnsupportedFrameworkVersionByRASP(Exception):
    """DO UnsupportedFrameworkVersionByRASP"""
    def __init__(self, framework, version):
        self.framework = framework
        self.version = version

    def __str__(self):
        return "{} in version {} is not supported by xArmor Python RASP".\
            format(self.framework.title(), self.version)


class UnsupportedPythonVersionByRASP(Exception):
    """DO UnsupportedPythonVersionByRASP"""
    def __init__(self, py_version):
        self.python_version = py_version

    def __str__(self):
        return "Python version {} is unsupported by xArmor Python RASP".\
            format(self.python_version)
