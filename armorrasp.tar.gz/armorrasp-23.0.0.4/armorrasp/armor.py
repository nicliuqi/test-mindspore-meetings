"""Do armor"""
from armorrasp.app_context import AppContext
from armorrasp.core.alarm_queue import AlarmQueue
from armorrasp.core.transport.upload_data import UploadData
from armorrasp.engine.middlewares import flask_middleware, django_middleware
from armorrasp.info.common import common_info
from armorrasp.plugins.cmdi import hook_subprocess, hook_os_system
from armorrasp.plugins.deserialize import hook_pickle_loads
from armorrasp.plugins.sqli import hook_mysql, hook_sqllite3
from armorrasp.plugins.traversal import hook_os_open, hook_builtin_open
from armorrasp.plugins.webshell import hook_save
from armorrasp.config import logger_config
from armorrasp.utils.pyrasp_exception import UnsupportedFrameworkVersionByRASP
from armorrasp.utils.pyrasp_exception import UnsupportedPythonVersionByRASP
from .__about__ import __version__

logger = logger_config("armor")

def logo_and_version():
    """Do logo_and_version"""
    print("""  _   _ _             ___               .             
 | | | (_)           / _ \                           .
 | |_| |_ ___  __  _/ /_\ \_ __ _ __ ___   ___  _ __ .
 |  _  | / __| \ \/ /  _  | '__| '_ ` _ \ / _ \| '__|.
 | | | | \__ \  >  <| | | | |  | | | | | | (_) | |   .
 \_| |_/_|___/ /_/\_\_| |_/_|  |_| |_| |_|\___/|_|   .
    """)
    print("\033[33m ({0}) \033[0m            \033[32m "
          "Powered By\033[0m\033[31m Huawei IT Security \033[0m"
          .format(__version__))


def run(queue):
    """Do armor_run"""
    try:

        hook_subprocess.do_patch(queue)
        hook_os_open.do_patch(queue)
        hook_os_system.do_patch(queue)

        hook_builtin_open.do_patch(queue)
        hook_save.do_patch(queue)
        hook_pickle_loads.do_patch(queue)

        hook_mysql.do_patch(queue)
        hook_sqllite3.do_patch(queue)

        flask_middleware.do_patch(queue)

        django_middleware.do_patch(queue)

    except Exception as err:
        logger.error('Hook failed', err)
    else:
        logger.info('Hook successful')


def start():
    """ Start protection
    """
    logo_and_version()

    try:
        runtime_app_infos = AppContext().get_agent_contexts()
    except UnsupportedFrameworkVersionByRASP as exception:
        msg = (
            "framework %s version %s is not supported in this agent version."
            "You're not protected by xArmor python rasp."
        )
        logger.critical(msg,
                        exception.framework.title(),
                        exception.version)
        return
    except UnsupportedPythonVersionByRASP as exception:
        msg = (
            "Python version %s is not supported in this agent version.\n"
            "you're not protected by xArmor python rasp."
        )
        logger.critical(
            msg, exception.python_version
        )
        return
    except Exception:
        msg = (
            "Runtime information about the system could not be retrieved."
            "You're not protected by xArmor python rasp."
        )
        logger.critical(msg)
        return
    common_info.update_info(runtime_app_infos)
    queue = AlarmQueue()
    agent_upload = UploadData(runtime_app_infos, queue)
    agent_upload.start_agent_register()
    agent_upload.start_push_log()

    run(queue)
