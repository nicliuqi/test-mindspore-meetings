"""Do core init work"""
