"""Do transport init work"""
