"""Do upload_data"""
import threading
import json
import requests


from armorrasp.config import CONFIG
from armorrasp.info.common import common_info
from armorrasp.config import logger_config

logger = logger_config("upload_data")


def fix_config(config):
    """Do fix_config"""
    for key in config:
        CONFIG[key.upper()] = config.get(key)


def update_config(config_json):
    """Do update_config"""
    fix_config(config_json.get("xArmor-python-rasp", {}).get("config", {}))


def get_alarm_body_data(data):
    """Do get_alarm_body_data"""
    res = {
        "X-xArmor-ApiName": "receiveAlarm",
        "logType": "AttackInfo",
        "data": []
    }
    res["data"].append(data)
    return res


class UploadData(object):
    """Do UploadData"""

    def __init__(self, infos, queue):
        self.infos = infos
        self.queue = queue
        self.pending_report = 0
        self.session = requests.session()
        self.agent_id = "0"
        self.registered = False
        self.interval = CONFIG["HEARTBEAT_INTERVAL"]
        self.last_update_time = -1
        self.headers = {
            "X-xArmor-Source": "agent",
            "X-xArmor-AgentType": "python_agent",
            "X-xArmor-Token": CONFIG["APP_TOKEN"],
            "X-xArmor-TenantId": CONFIG["TENANT_ID"],
            "X-xArmor-SubTenantId": CONFIG["TENANT_ID"],
            "X-xArmor-AppId": CONFIG["APP_ID"],
            "X-xArmor-AgentId": CONFIG["AGENT_ID"],
            "Connection": "close"
        }

    def creat_headers(self):
        res = self.headers
        res.update({"X-xArmor-AgentId": CONFIG["AGENT_ID"]})
        return res

    def base_report(self, body):
        url = CONFIG["BACKEND_URL"]
        stream_data = json.dumps(body)
        try:
            res = self.session.post(url, data=stream_data,
                                    timeout=20, headers=self.creat_headers())
            resp = res.content.decode("utf-8")
            resp_json = json.loads(resp)
        except Exception as e:
            logger.error("report data error " + str(e))
            resp_json = {}

        return resp_json

    def start_agent_heartbeat(self):
        self.heartbeat_report()
        t1 = threading.Timer(int(self.interval), self.start_agent_heartbeat)
        # 启动线程
        t1.start()

    def heartbeat_report(self):
        if self.agent_id != "0":
            try:
                body_data = {"X-xArmor-ApiName": "receiveHeartBeat",
                             "data": {"lastUpdateTime": self.last_update_time}}

                heart_resp = self.base_report(body_data)
                array_config = heart_resp.get("data", {}).get("config", {})
                dic_config = {}
                for a in array_config:
                    dic_config.update(a)

                l_u_t = dic_config.get("lastUpdateTime", -1)
                if l_u_t != self.last_update_time:
                    config = dic_config.get("xArmorModuleConfig", {})
                    self.last_update_time = l_u_t
                    update_config(config)

            except Exception as ex:
                logger.error("send heartbeat error occurred " + str(ex))
        else:
            logger.warn("ignored heartbeat before register.")

    def start_agent_register(self):
        if self.agent_register():
            logger.info("register failed and start register schedule job")
            agent_register_thread = \
                threading.Timer(int(self.interval), self.agent_register)
            agent_register_thread.start()
            if self.registered:
                agent_register_thread.cancel()

    def agent_register(self):
        try:
            body_data = {"X-xArmor-ApiName": "registerAgent",
                         "data": self.infos}

            resp = self.base_report(body_data)
            if resp.get("status", 0) == 200:

                array_config = resp.get("data", {}).get("config", {})
                dic_config = {}
                for a in array_config:
                    dic_config.update(a)

                self.last_update_time = dic_config.get("lastUpdateTime", -1)
                self.agent_id = \
                    dic_config.get("xArmorConfig",
                                   {}).get("backendConfig",
                                           {}).get("agentId", "0")
                config = dic_config.get("xArmorModuleConfig", {})
                CONFIG["AGENT_ID"] = self.agent_id
                common_info.update_agent_id(self.agent_id)
                update_config(config)
                self.registered = True
                self.start_agent_heartbeat()
                return False
            else:
                logger.info(resp)
        except Exception as ex:
            logger.error("report data error " + str(ex))
        return True

    def start_push_log(self):
        self.push_log()

        push_log_thread = threading.Timer(1, self.start_push_log)
        push_log_thread.daemon = True
        push_log_thread.start()

    def push_log(self):
        if self.queue is not None:
            try:
                alarm = self.queue.get(10, block=False)
                if alarm is not None:
                    json_alarm = json.dumps(alarm)
                    logger.info("Detect attack, %s"
                                % json_alarm)
                    self.post_alarm_banckend(alarm)
            except Exception as ex:
                pass
        else:
            logger.warning("alarm_queue is None")

    def post_alarm_banckend(self, data):
        try:
            res = self.base_report(get_alarm_body_data(data))
        except Exception as e:
            logger.error("report alarm error " + str(e))
            res = {}

        if res.get("status", 0) == 200:
            logger.info("report alarm data success")
        else:
            logger.error("report alarm data error")
