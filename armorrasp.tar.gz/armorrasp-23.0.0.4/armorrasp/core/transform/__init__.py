"""Do transform init work"""
