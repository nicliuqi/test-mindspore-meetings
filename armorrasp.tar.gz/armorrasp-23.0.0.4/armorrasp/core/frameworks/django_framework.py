"""Do django_framework"""
from copy import deepcopy

from armorrasp.core.frameworks.wsgi_base import BasisWSGIRequest
from armorrasp.config import logger_config
from armorrasp.utils.util import secured_unicode, cached_property

logger = logger_config("django_framework")


class BasisDjangoRequest(BasisWSGIRequest):
    """Do BasisDjangoRequest"""

    def __init__(self, request):
        super(BasisDjangoRequest, self).__init__()
        self.request = request

    def data_preloaded(self):
        try:
            self.request.body
        except Exception:
            return False
        else:
            return True

    @cached_property
    def query_params_to_dict(self):
        try:
            return dict(self.request.GET.lists())
        except Exception:
            logger.debug("can't get request.GET from framework",
                         exc_info=True)
            return super(BasisDjangoRequest, self).query_params_to_dict

    @property
    def body(self):
        try:
            if self.data_preloaded():
                return self.request.body
        except Exception:
            logger.debug("can't get request.body from framework",
                         exc_info=True)
        return super(BasisDjangoRequest, self).body

    @cached_property
    def form_body_to_dict(self):
        try:
            if self.data_preloaded():
                return deepcopy(self.request.POST)
        except Exception:

            logger.debug("can't get request.POST from framework",
                         exc_info=True)
        return super(BasisDjangoRequest, self).form_body_to_dict

    @cached_property
    def cookies_params(self):
        try:
            return self.request.COOKIES
        except Exception:
            logger.debug("can't get request.COOKIES from framework",
                         exc_info=True)
            return super(BasisDjangoRequest, self).cookies_params

    @property
    def remote_addr(self):
        return secured_unicode(self.get_raw_header("REMOTE_ADDR"))

    @property
    def hostname(self):
        try:
            return self.request.get_host()
        except Exception:
            logger.debug("can't get request.get_host from framework",
                         exc_info=True)
            return None

    @property
    def request_method(self):
        return self.request.method

    @property
    def header_referer(self):
        return secured_unicode(self.get_raw_header("HTTP_REFERER"))

    @property
    def user_agent(self):
        return secured_unicode(self.get_raw_header("HTTP_USER_AGENT"))

    @property
    def route(self):
        """请求路由"""
        resolver_match = getattr(self.request, "resolver_match", None)
        return getattr(resolver_match, "route", None)

    @property
    def request_path(self):
        return self.request.path

    @property
    def scheme(self):
        return getattr(self.request, "scheme", None)

    @property
    def raw_headers(self):
        return self.request.META

    @property
    def view_params(self):
        accouple_resolver = getattr(self.request, "resolver_match", None)
        if accouple_resolver:
            return accouple_resolver.kwargs

    @property
    def request_uri(self):
        return secured_unicode(self.request.get_full_path())
