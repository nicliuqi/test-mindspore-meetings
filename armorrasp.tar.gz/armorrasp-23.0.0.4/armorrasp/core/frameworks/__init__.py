"""Do frameworks init work"""
