"""Do alarm_consumer"""
import json
import queue
import threading
import time

from armorrasp.config import logger_config

logger = logger_config("alarm_consumer")


class AlarmCalculator(threading.Thread):
    """Do AlarmCalculator"""
    alarm_queue = queue.Queue(1000)

    @staticmethod
    def get_alarm_queue():
        return

    def __init__(self, name):
        threading.Thread.__init__(self, name=name)

    def deal_alarm(self):
        if AlarmCalculator.alarm_queue is not None:
            try:
                time.sleep(0.1)
                alarm = AlarmCalculator.alarm_queue.get(block=False)
                if alarm is not None:
                    json_alarm = json.dumps(alarm.__dict__)
            except queue.Empty as ex:
                pass
        else:
            logger.warning("alarm_queue is None")

    def run(self):
        try:
            logger.info("Starting %s" % self.name)
            while True:
                AlarmCalculator.deal_alarm(self)
        except Exception as ex:
            logger.warning('alarm_calculate_thread is down')
        return
